agGrid.initialiseAgGridWithAngular1(angular);
searchApp.controller('searchCtrl', function ($scope, $http, $timeout, fetchService, $window) {
    $window.onload = function () {
        $('#divMain').show();
    };
    $scope.oneAtATime = false;
    $scope.isExportDisabled = true;
    $scope.displayMessage = false;
    $scope.showBlockUI = true;
    $scope.showUnBlockUI = false;
    // $scope.listViews = ["(For MBJ) All Items", "(For MBJ) MBJ Summary", "(For MBJ) IPS View", "(For MBJ) LEG Summary", "(For MBJ) Dept Managed", "(For FS) All Items"];
    $scope.listViews = {
        availableOptions: [
            { id: '1', name: '(For MBJ) All Items' },
            { id: '2', name: '(For MBJ) MBJ Summary' },
            { id: '3', name: '(For MBJ) IPS View' },
            { id: '4', name: '(For MBJ) LEG Summary' },
            { id: '5', name: '(For MBJ) Dept Managed' },
            { id: '6', name: '(For FS) All Items' },

        ],
        selectedOption: { id: '1', name: '(For MBJ) All Items' } //This sets the default value of the select in the ui
    };
    $scope.chkStatusList = ["Unapproved", "MBJ Sealed", "Filed", "Canceled"];
    $scope.ResultCount = '';
    $scope.TrimCount = '';
    var columnDefs = [
        {
            headerName: "Title", field: "ListName&ID&Title", width: 100, cellRenderer: IdLinkCellRendererFunc, valueGetter: function aPlusBValueGetter(params) {
                return params.data.ListName + "_" + params.data.ID + "_" + params.data.Title;
            }
        },
        { headerName: "Contract Status", field: "ContractStatus", width: 150 },
        // { headerName: "Title", field: "Title", width: 100 },
        { headerName: "Contractor1_ JP", field: "Contractor1_JP", width: 150 },
        { headerName: "Contractor1_EN", field: "Contractor1_EN", width: 150 },
        { headerName: "Contractor2_ JP", field: "Contractor2_JP", width: 150 },
        { headerName: "Contractor2_EN", field: "Contractor2_EN", width: 150 },
        { headerName: "Contractor3_ JP", field: "Contractor3_JP", width: 150 },
        { headerName: "Contractor3_EN", field: "Contractor3_EN", width: 150 },
        { headerName: "Contractor4_ JP", field: "Contractor4_JP", width: 150 },
        { headerName: "Contractor4_EN", field: "Contractor4_EN", width: 150 },
        { headerName: "Contractor5_ JP", field: "Contractor5_JP", width: 150 },
        { headerName: "Contractor5_EN", field: "Contractor5_EN", width: 150 },
        { headerName: "Vendor Code1", field: "VendorCode1", width: 60 },
        { headerName: "Vendor Code2", field: "VendorCode2", width: 60 },
        { headerName: "Vendor Code3", field: "VendorCode3", width: 60 },
        { headerName: "Contractant", field: "Contractant", width: 60 },
        { headerName: "Contract Holder Choice", field: "ContractHolderChoice", width: 180 },
        { headerName: "ContractHolder_LEG", field: "ContractHolder_LEG", width: 180 },
        { headerName: "ContractHolder_Dept", field: "ContractHolder_Dept", width: 180 },
        { headerName: "Location Number", field: "LocationNumber", width: 150 },
        { headerName: "Contract Name", field: "ContractName", width: 180 },
        { headerName: "Contract Date", field: "ContractDate", width: 130, cellRenderer: dateCellRendererFunc },
        { headerName: "Contract Type", field: "ContractType", width: 180 },
        { headerName: "Contract Type Other", field: "ContractTypeOther", width: 150 },
        { headerName: "EntryDate", field: "EntryDate", width: 100, cellRenderer: dateCellRendererFunc },
        { headerName: "Entry Department", field: "EntryDepartment", width: 100, },
        { headerName: "Effective DateFrom", field: "EffectiveDateFrom", width: 135, cellRenderer: dateCellRendererFunc },
        { headerName: "Effective DateTo ", field: "EffectiveDateTo", width: 135, cellRenderer: dateCellRendererFunc },
        { headerName: "LegalTerminatedDateActual", field: "LegalTerminatedDateActual", width: 100, cellRenderer: dateCellRendererFunc },
        { headerName: "ContractHandedOverTo", field: "ContractHandedOverTo", width: 150 },
        { headerName: "Contract Dept", field: "ContractDept", width: 130 },
        { headerName: "Contact Person", field: "ContactPerson", width: 180 },
        { headerName: "AntibriberyClause", field: "AntibriberyClause", width: 180 },
        { headerName: "IPSrelated", field: "IPSrelated", width: 80 },
        { headerName: "PriorNoticeForRenewal", field: "PriorNoticeForRenewal", width: 150 },
        { headerName: "PriorNoticeForRenewalForIPS", field: "PriorNoticeForRenewalForIPS", width: 80, cellRenderer: dateCellRendererFunc },
        { headerName: "Renewal Period", field: "RenewalPeriod", width: 100 },
        { headerName: "RenewedEffectiveDateTo", field: "RenewedEffectiveDateTo", width: 100, cellRenderer: dateCellRendererFunc },
        { headerName: "Automatic Renewal", field: "AutomaticRenewal", width: 150 },
        { headerName: "ProcurementTerminationFlag", field: "ProcurementTerminationFlag", width: 150 },
        { headerName: "Contract Amount", field: "ContractAmount", width: 150 },
        { headerName: "Currency", field: "Currency", width: 150 },
        { headerName: "Unit Price Agreed ", field: "UnitPriceAgreed ", width: 150 },
        { headerName: "Current Responsible Department", field: "CurrentResponsibleDepartment", width: 150 },
        { headerName: "Current Contact Person", field: "CurrentContactPerson", width: 150 },
        { headerName: "Memo", field: "Memo", width: 200, cellRenderer: multilineCellRendererFunc },
        { headerName: "Link To Other Contracts", field: "LinkToOtherContracts", width: 150 },
        { headerName: "Entity At Time Of Contracted", field: "EntityAtTimeOfContracted", width: 150 },
        { headerName: "Amount of StampDuty1", field: "AmountofStampDuty1", width: 150 },
        { headerName: "Amount of StampDuty2", field: "AmountofStampDuty2", width: 150 },
        { headerName: "Sealed Date", field: "Sealed Date", width: 150, cellRenderer: dateCellRendererFunc, hide: true },
        { headerName: "Stamp Duty", field: "StampDuty", width: 180,hide: true },
    ];


    $scope.checkErr = function (startDate, endDate) {
        $scope.errMessage = '';
        if (new Date(startDate) > new Date(endDate)) {
            $scope.errMessage = 'To Date should be greater than From date';
            $scope.displayMessage = true;
            $scope.searchResults = false;
            return false;
        }
    };
    $(function () {
        $('#ms-help').hide();
        $(".allownumericwithoutdecimal").on("keypress keyup blur", function (event) {
            $(this).val($(this).val().replace(/[^\d].+/, ""));
            if ((event.which < 48 || event.which > 57)) {
                event.preventDefault();
                $scope.$apply();
            }
        });

        $("[name='contractDateFrom']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.contractDateFrom = date;
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='contractDateTo']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.contractDateTo = date;
                $scope.checkErr($scope.newItem.contractDateFrom, $scope.newItem.contractDateTo);
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='EntryDateFrom']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.EntryDateFrom = date;
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='EntryDateTo']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.EntryDateTo = date;
                $scope.checkErr($scope.newItem.EntryDateFrom, $scope.newItem.EntryDateTo);
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='LegalTerminatedDateActualFrom']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.LegalTerminatedDateActualFrom = date;
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='LegalTerminatedDateActualTo']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.LegalTerminatedDateActualTo = date;
                $scope.checkErr($scope.newItem.LegalTerminatedDateActualFrom, $scope.newItem.LegalTerminatedDateActualTo);
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='EffectiveDateFrom']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.EffectiveDateFrom = date;
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='EffectiveDateTo']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.EffectiveDateTo = date;
                $scope.checkErr($scope.newItem.EffectiveDateFrom, $scope.newItem.EffectiveDateTo);
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='PriorNoticeForRenewalForIPSFrom']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.PriorNoticeForRenewalForIPSFrom = date;
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='PriorNoticeForRenewalForIPSTo']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.PriorNoticeForRenewalForIPSTo = date;
                $scope.checkErr($scope.newItem.PriorNoticeForRenewalForIPSFrom, $scope.newItem.PriorNoticeForRenewalForIPSTo);
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='RenewedEffectiveDateToFrom']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.RenewedEffectiveDateToFrom = date;
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='RenewedEffectiveDateToTo']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.RenewedEffectiveDateToTo = date;
                $scope.checkErr($scope.newItem.RenewedEffectiveDateToFrom, $scope.newItem.RenewedEffectiveDateToTo);
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='SealedDateFrom']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.SealedDateFrom = date;
                $scope.$apply();
                console.log($scope);
            }
        });
        $("[name='SealedDateTo']").datepicker({
            changeYear: true,
            changeMonth: true,
            yearRange: '1900:-0',
            dateFormat: 'yy/mm/dd',
            onSelect: function (date) {
                $scope.newItem.SealedDateTo = date;
                $scope.checkErr($scope.newItem.SealedDateFrom, $scope.newItem.SealedDateTo);
                $scope.$apply();
                console.log($scope);
            }
        });
    });
    function IdLinkCellRendererFunc(params) {
        var val = params.value.split('_');
        if (val[0] == 'null') {
            return '<a target="_blank" href="https://team.uat.sp.wp.corpintra.net/sites/05420/MBJContractDB/Lists/Contracts/DispContractForm.aspx?ID=' + val[1] + '">' + val[2] + '</a>'
        }
        else {
            return '<a target="_blank" href="https://team.uat.sp.wp.corpintra.net/sites/05420/MBJContractDB/Lists/' + val[0] + '/DisplayContractPast.aspx?ID=' + val[1] + '">' + val[2] + '</a>'
        }
    }
    function dateCellRendererFunc(params) {
        if (params.value != null) {
            var date = new Date(params.value),
                month = '' + (date.getMonth() + 1),
                day = '' + date.getDate(),
                year = date.getFullYear();
            if (month.length < 2) month = '0' + month;
            if (day.length < 2) day = '0' + day;
            return [year, month, day].join('/');
        }
    }
    function multilineCellRendererFunc(params) {
        if (params.value != null) {
            var tag = document.createElement('div');
            tag.innerHTML = params.value;
            return tag.innerText;
        }
    }
    function dateFormat(dateValue) {
        var date = new Date(dateValue),
            month = '' + (date.getMonth() + 1),
            day = '' + date.getDate(),
            year = date.getFullYear();
        if (month.length < 2) month = '0' + month;
        if (day.length < 2) day = '0' + day;
        return [year, month, day].join('/');
    }

    $scope.newItem = {
        SimpleFromdate: [],
        SimpleTodate: [],
        cbs: []
    };

    $scope.items = [];

    fetchService.getItems("Contracts").then(function (result) {
        $.each(result, function (index, item) {
            //Create the item from the request JSON result.                
            var singleItem = {
                ID: item.ID,
                ListName: item.ListName,
                ContractStatus: item.ContractStatus,
                Title: item.Title,
                Contractor1_JP: item.Contractor1_JP,
                Contractor1_EN: item.Contractor1_EN,
                Contractor2_JP: item.Contractor2_JP,
                Contractor2_EN: item.Contractor2_EN,
                Contractor3_JP: item.Contractor3_JP,
                Contractor3_EN: item.Contractor3_EN,
                Contractor4_JP: item.Contractor4_JP,
                Contractor4_EN: item.Contractor4_EN,
                Contractor5_JP: item.Contractor5_JP,
                Contractor5_EN: item.Contractor5_EN,
                VendorCode1: item.VendorCode1,
                VendorCode2: item.VendorCode2,
                VendorCode3: item.VendorCode3,
                Contractant: item.Contractant,
                ContractHolderChoice: item.ContractHolderChoice,
                ContractHolder_LEG: item.ContractHolder_LEG,
                ContractHolder_Dept: item.ContractHolder_Dept,
                LocationNumber: item.LocationNumber,
                ContractName: item.ContractName,
                ContractDate: item.ContractDate,
                ContractType: item.ContractType,
                ContractTypeOther: item.ContractTypeOther,
                EntryDate: item.EntryDate,
                EntryDepartment: item.EntryDepartment,
                EffectiveDateFrom: item.EffectiveDateFrom,
                EffectiveDateTo: item.EffectiveDateTo,
                LegalTerminatedDateActual: item.LegalTerminatedDateActual,
                ContractHandedOverTo: item.ContractHandedOverTo,
                ContractDept: item.ContractDept,
                ContactPerson: item.ContactPerson,
                AntibriberyClause: item.AntibriberyClause,
                IPSrelated: item.IPSrelated,
                PriorNoticeForRenewal: item.PriorNoticeForRenewal,
                PriorNoticeForRenewalForIPS: item.PriorNoticeForRenewalForIPS,
                RenewalPeriod: item.RenewalPeriod,
                RenewedEffectiveDateTo: item.RenewedEffectiveDateTo,
                AutomaticRenewal: item.AutomaticRenewal,
                ProcurementTerminationFlag: item.ProcurementTerminationFlag,
                ContractAmount: item.ContractAmount,
                Currency: item.Currency,
                UnitPriceAgreed: item.UnitPriceAgreed,
                CurrentResponsibleDepartment: item.CurrentResponsibleDepartment,
                CurrentContactPerson: item.CurrentContactPerson,
                Memo: item.Memo,
                LinkToOtherContracts: item.LinkToOtherContracts,
                EntityAtTimeOfContracted: item.EntityAtTimeOfContracted,
                AmountofStampDuty1: item.AmountofStampDuty1,
                AmountofStampDuty2: item.AmountofStampDuty2,
                SealedDate: item.SealedDate,
                StampDuty:item.StampDuty
            }
            $scope.items.push(singleItem);
        });
    });

    fetchService.getItems("ContractsPast").then(function (result) {
        $.each(result, function (index, item) {
            $scope.showBlockUI = false;
            $scope.showUnBlockUI = true;
            //Create the item from the request JSON result.                
            var singleItem = {
                ID: item.ID,
                ListName: item.ListName,
                ContractStatus: item.ContractStatus,
                Title: item.Title,
                Contractor1_JP: item.Contractor1_JP,
                Contractor1_EN: item.Contractor1_EN,
                Contractor2_JP: item.Contractor2_JP,
                Contractor2_EN: item.Contractor2_EN,
                Contractor3_JP: item.Contractor3_JP,
                Contractor3_EN: item.Contractor3_EN,
                Contractor4_JP: item.Contractor4_JP,
                Contractor4_EN: item.Contractor4_EN,
                Contractor5_JP: item.Contractor5_JP,
                Contractor5_EN: item.Contractor5_EN,
                VendorCode1: item.VendorCode1,
                VendorCode2: item.VendorCode2,
                VendorCode3: item.VendorCode3,
                Contractant: item.Contractant,
                ContractHolderChoice: item.ContractHolderChoice,
                ContractHolder_LEG: item.ContractHolder_LEG,
                ContractHolder_Dept: item.ContractHolder_Dept,
                LocationNumber: item.LocationNumber,
                ContractName: item.ContractName,
                ContractDate: item.ContractDate,
                ContractType: item.ContractType,
                ContractTypeOther: item.ContractTypeOther,
                EntryDate: item.EntryDate,
                EntryDepartment: item.EntryDepartment,
                EffectiveDateFrom: item.EffectiveDateFrom,
                EffectiveDateTo: item.EffectiveDateTo,
                LegalTerminatedDateActual: item.LegalTerminatedDateActual,
                ContractHandedOverTo: item.ContractHandedOverTo,
                ContractDept: item.ContractDept,
                ContactPerson: item.ContactPerson,
                AntibriberyClause: item.AntibriberyClause,
                IPSrelated: item.IPSrelated,
                PriorNoticeForRenewal: item.PriorNoticeForRenewal,
                PriorNoticeForRenewalForIPS: item.PriorNoticeForRenewalForIPS,
                RenewalPeriod: item.RenewalPeriod,
                RenewedEffectiveDateTo: item.RenewedEffectiveDateTo,
                AutomaticRenewal: item.AutomaticRenewal,
                ProcurementTerminationFlag: item.ProcurementTerminationFlag,
                ContractAmount: item.ContractAmount,
                Currency: item.Currency,
                UnitPriceAgreed: item.UnitPriceAgreed,
                CurrentResponsibleDepartment: item.CurrentResponsibleDepartment,
                CurrentContactPerson: item.CurrentContactPerson,
                Memo: item.Memo,
                LinkToOtherContracts: item.LinkToOtherContracts,
                EntityAtTimeOfContracted: item.EntityAtTimeOfContracted,
                AmountofStampDuty1: item.AmountofStampDuty1,
                AmountofStampDuty2: item.AmountofStampDuty2,
                SealedDate: item.SealedDate,
                StampDuty:item.StampDuty
            }
            $scope.items.push(singleItem);
        });

    });
    $scope.btnSearch = function (newItem) {
        if (!(typeof newItem.contractor == 'undefined' || !newItem.contractor)
            || !(typeof newItem.contractname == 'undefined' || !newItem.contractname)
            || !(typeof newItem.title == 'undefined' || !newItem.title)
            || !(typeof newItem.location == 'undefined' || !newItem.location)
            || !(typeof newItem.contactperson == 'undefined' || !newItem.contactperson)
            || !(typeof newItem.contractdept == 'undefined' || !newItem.contractdept)
            || !(typeof newItem.contractDateFrom == 'undefined' || !newItem.contractDateFrom)
            || newItem.cbs.length != 0
            || !(typeof newItem.EntryDateFrom == 'undefined' || !newItem.EntryDateFrom)
            || !(typeof newItem.Contractant == 'undefined' || !newItem.Contractant)
            || !(typeof newItem.EntityAtTimeOfContracted == 'undefined' || !newItem.EntityAtTimeOfContracted)
            || !(typeof newItem.ContractType == 'undefined' || !newItem.ContractType)
            || !(typeof newItem.ContractTypeOther == 'undefined' || !newItem.ContractTypeOther)
            || !(typeof newItem.ContractHolderLEG == 'undefined' || !newItem.ContractHolderLEG)
            || !(typeof newItem.ContractHolder_Dept == 'undefined' || !newItem.ContractHolder_Dept)
            || !(typeof newItem.EntryDepartment == 'undefined' || !newItem.EntryDepartment)
            || !(typeof newItem.ContractHandedOverTo == 'undefined' || !newItem.ContractHandedOverTo)
            || !(typeof newItem.CurrentResponsibleDepartment == 'undefined' || !newItem.CurrentResponsibleDepartment)
            || !(typeof newItem.CurrentContactPerson == 'undefined' || !newItem.CurrentContactPerson)
            || !(typeof newItem.ContractMemo == 'undefined' || !newItem.ContractMemo)
            || !(typeof newItem.LinkToOtherContracts == 'undefined' || !newItem.LinkToOtherContracts)
            || !(typeof newItem.ContractPurpose == 'undefined' || !newItem.ContractPurpose)
            || !(typeof newItem.AntibriberyClause == 'undefined' || !newItem.AntibriberyClause)
            || !(typeof newItem.StampDuty == 'undefined' || !newItem.StampDuty)
            || !(typeof newItem.ContractHolderChoice == 'undefined' || !newItem.ContractHolderChoice)
            || !(typeof newItem.UnitPriceAgreed == 'undefined' || !newItem.UnitPriceAgreed)
            || !(typeof newItem.IPSrelated == 'undefined' || !newItem.IPSrelated)
            || !(typeof newItem.AutomaticRenewal == 'undefined' || !newItem.AutomaticRenewal)
            || !(typeof newItem.ProcurementTerminationFlag == 'undefined' || !newItem.ProcurementTerminationFlag)
            || !(typeof newItem.Currency == 'undefined' || !newItem.Currency)
            || !(typeof newItem.EntryDateTo == 'undefined' || !newItem.EntryDateTo)
            || !(typeof newItem.contractDateTo == 'undefined' || !newItem.contractDateTo)
            || !(typeof newItem.LegalTerminatedDateActualTo == 'undefined' || !newItem.LegalTerminatedDateActualTo)
            || !(typeof newItem.LegalTerminatedDateActualFrom == 'undefined' || !newItem.LegalTerminatedDateActualFrom)
            || !(typeof newItem.EffectiveDateFrom == 'undefined' || !newItem.EffectiveDateFrom)
            || !(typeof newItem.EffectiveDateTo == 'undefined' || !newItem.EffectiveDateTo)
            || !(typeof newItem.PriorNoticeForRenewalForIPSFrom == 'undefined' || !newItem.PriorNoticeForRenewalForIPSFrom)
            || !(typeof newItem.PriorNoticeForRenewalForIPSTo == 'undefined' || !newItem.PriorNoticeForRenewalForIPSTo)
            || !(typeof newItem.RenewedEffectiveDateToFrom == 'undefined' || !newItem.RenewedEffectiveDateToFrom)
            || !(typeof newItem.RenewedEffectiveDateToTo == 'undefined' || !newItem.RenewedEffectiveDateToTo)
            || !(typeof newItem.ContractAmountFrom == 'undefined' || !newItem.ContractAmountFrom)
            || !(typeof newItem.ContractAmountTo == 'undefined' || !newItem.ContractAmountTo)
            || !(typeof newItem.SealedDateFrom == 'undefined' || !newItem.SealedDateFrom)
            || !(typeof newItem.SealedDateTo == 'undefined' || !newItem.SealedDateTo)
            || !(typeof newItem.AmountofStampDuty1From == 'undefined' || !newItem.AmountofStampDuty1From)
            || !(typeof newItem.AmountofStampDuty1To == 'undefined' || !newItem.AmountofStampDuty1To)
            || !(typeof newItem.AmountofStampDuty2To == 'undefined' || !newItem.AmountofStampDuty2To)
            || !(typeof newItem.AmountofStampDuty2From == 'undefined' || !newItem.AmountofStampDuty2From)
            || !(typeof newItem.PriorNoticeForRenewalFrom == 'undefined' || !newItem.PriorNoticeForRenewalFrom)
            || !(typeof newItem.PriorNoticeForRenewalTo == 'undefined' || !newItem.PriorNoticeForRenewalTo)
            || !(typeof newItem.RenewalPeriodFrom == 'undefined' || !newItem.RenewalPeriodFrom)
            || !(typeof newItem.RenewalPeriodTo == 'undefined' || !newItem.RenewalPeriodTo)) {
            // if (newItem.contractor != (null ||'')  || newItem.contractname != (null||'')
            //     || newItem.title != null  || newItem.location != null 
            //     || newItem.contactperson != (null && "") || newItem.contractdept != null || newItem.contractDateFrom != null || newItem.cbs.length != 0
            //     || newItem.EntryDateFrom != null || newItem.Contractant != null || newItem.EntityAtTimeOfContracted != null || newItem.ContractType != null
            //     || newItem.ContractTypeOther != null || newItem.ContractHolderLEG != null || newItem.ContractHolder_Dept != null || newItem.EntryDepartment != null
            //     || newItem.ContractHandedOverTo != null || newItem.CurrentResponsibleDepartment != null || newItem.CurrentContactPerson != null || newItem.ContractMemo != null
            //     || newItem.LinkToOtherContracts != null || newItem.ContractPurpose != null || newItem.AntibriberyClause != null || newItem.StampDuty != null || newItem.ContractHolderChoice != null
            //     || newItem.UnitPriceAgreed != null || newItem.IPSrelated != null || newItem.AutomaticRenewal != null || newItem.ProcurementTerminationFlag != null || newItem.Currency != null || newItem.EntryDateTo != null
            //     || newItem.contractDateTo != null || newItem.LegalTerminatedDateActualTo != null || newItem.LegalTerminatedDateActualFrom != null || newItem.EffectiveDateFrom != null
            //     || newItem.EffectiveDateTo != null || newItem.PriorNoticeForRenewalForIPSFrom != null || newItem.PriorNoticeForRenewalForIPSTo != null || newItem.RenewedEffectiveDateToFrom != null
            //     || newItem.RenewedEffectiveDateToTo != null || newItem.ContractAmountFrom != null || newItem.ContractAmountTo != null || newItem.SealedDateFrom != null || newItem.SealedDateTo != null || newItem.AmountofStampDuty1From != null
            //     || newItem.AmountofStampDuty1To != null || newItem.AmountofStampDuty2To != null || newItem.AmountofStampDuty2From != null || newItem.PriorNoticeForRenewalFrom != null || newItem.PriorNoticeForRenewalTo != null
            //     || newItem.RenewalPeriodFrom != null || newItem.RenewalPeriodTo != null){

            $scope.searchResults = true;
            $scope.isExportDisabled = false;
            $scope.displayMessage = false;
            $scope.errMessage = '';
            $scope.tempItems = angular.copy($scope.items);
            if (!(typeof newItem.contractor == 'undefined' || !newItem.contractor)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.Contractor1_JP != null) return angular.lowercase(v.Contractor1_JP).indexOf(angular.lowercase(newItem.contractor)) !== -1;
                });
            }
            if (!(typeof newItem.contractname == 'undefined' || !newItem.contractname)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractName != null) return angular.lowercase(v.ContractName).indexOf(angular.lowercase(newItem.contractname)) !== -1;
                });
            }
            if (!(typeof newItem.contactperson == 'undefined' || !newItem.contactperson)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContactPerson != null) return angular.lowercase(v.ContactPerson).indexOf(angular.lowercase(newItem.contactperson)) !== -1;
                });
            }
            if (!(typeof newItem.location == 'undefined' || !newItem.location)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.LocationNumber != null) return angular.lowercase(v.LocationNumber).indexOf(angular.lowercase(newItem.location)) !== -1;
                });
            }
            if (!(typeof newItem.title == 'undefined' || !newItem.title)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.Title != null) return angular.lowercase(v.Title).indexOf(angular.lowercase(newItem.title)) !== -1;
                });
            }
            if (!(typeof newItem.contractdept == 'undefined' || !newItem.contractdept)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractDept != null) return angular.lowercase(v.ContractDept).indexOf(angular.lowercase(newItem.contractdept)) !== -1;
                });
            }
            if (!(typeof newItem.contractDateFrom == 'undefined' || !newItem.contractDateFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractDate != null) {
                        var chkiDate = dateFormat(v.ContractDate);
                        var chkDate = conversionDate(chkiDate);
                        var fromDate = conversionDate(newItem.contractDateFrom);
                        if (fromDate <= chkDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.contractDateTo == 'undefined' || !newItem.contractDateTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractDate != null) {
                        var chkiDate = dateFormat(v.ContractDate);
                        var chkDate = conversionDate(chkiDate),
                            toDate = conversionDate(newItem.contractDateTo);
                        if (chkDate <= toDate) {
                            return true;
                        }
                    }
                });
            }
            if (newItem.cbs.length != 0) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    switch (newItem.cbs.length) {
                        case 4:
                           if (v.ContractStatus == newItem.cbs[0] || v.ContractStatus == newItem.cbs[1] || v.ContractStatus == newItem.cbs[2] || v.ContractStatus == newItem.cbs[3]) { return true; }
                            break;
                        case 3:
                            if (v.ContractStatus == newItem.cbs[0] || v.ContractStatus == newItem.cbs[1] || v.ContractStatus == newItem.cbs[2]) { return true; }
                            break;
                        case 2:
                            if (v.ContractStatus == newItem.cbs[0] || v.ContractStatus == newItem.cbs[1]) { return true; }
                            break;
                        case 1:
                            if (v.ContractStatus == newItem.cbs[0]) { return true; }
                            break;
                    }
                });
            }
            if (!(typeof newItem.EntryDateFrom == 'undefined' || !newItem.EntryDateFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.EntryDate != null) {
                        var chkiDate = dateFormat(v.EntryDate);
                        var chkDate = conversionDate(chkiDate),
                            fromDate = conversionDate(newItem.EntryDateFrom);
                        if (fromDate <= chkDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.EntryDateTo == 'undefined' || !newItem.EntryDateTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.EntryDate != null) {
                        var chkiDate = dateFormat(v.EntryDate);
                        var chkDate = conversionDate(chkiDate),
                            toDate = conversionDate(newItem.EntryDateTo);
                        if (chkDate <= toDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.LegalTerminatedDateActualFrom == 'undefined' || !newItem.LegalTerminatedDateActualFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.LegalTerminatedDateActual != null) {
                        var chkiDate = dateFormat(v.LegalTerminatedDateActual);
                        var chkDate = conversionDate(chkiDate),
                            fromDate = conversionDate(newItem.LegalTerminatedDateActualFrom);
                        if (fromDate <= chkDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.LegalTerminatedDateActualTo == 'undefined' || !newItem.LegalTerminatedDateActualTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.LegalTerminatedDateActual != null) {
                        var chkiDate = dateFormat(v.LegalTerminatedDateActual);
                        var chkDate = conversionDate(chkiDate),
                            toDate = conversionDate(newItem.LegalTerminatedDateActualTo);
                        if (chkDate <= toDate) {
                            return true;
                        }
                    }
                });
            }
            if (newItem.EffectiveDateFrom != null && newItem.EffectiveDateTo != null) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.EffectiveDateFrom != null) {
                        var chkiDate = dateFormat(v.EffectiveDateFrom);
                        var chkDate = conversionDate(chkiDate),
                            fromDate = conversionDate(newItem.EffectiveDateFrom),
                            toDate = conversionDate(newItem.EffectiveDateTo);
                        if (fromDate <= chkDate && chkDate <= toDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.EffectiveDateFrom == 'undefined' || !newItem.EffectiveDateFrom)) {

                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.EffectiveDateFrom != null) {
                        var chkiDate = dateFormat(v.EffectiveDateFrom);
                        var chkDate = conversionDate(chkiDate),
                            fromDate = conversionDate(newItem.EffectiveDateFrom);
                        if (fromDate <= chkDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.EffectiveDateTo == 'undefined' || !newItem.EffectiveDateTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.EffectiveDateFrom != null) {
                        var chkiDate = dateFormat(v.EffectiveDateFrom);
                        var chkDate = conversionDate(chkiDate),
                            toDate = conversionDate(newItem.EffectiveDateTo);
                        if (chkDate <= toDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.PriorNoticeForRenewalForIPSFrom == 'undefined' || !newItem.PriorNoticeForRenewalForIPSFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.PriorNoticeForRenewalForIPS != null) {
                        var chkiDate = dateFormat(v.PriorNoticeForRenewalForIPS);
                        var chkDate = conversionDate(chkiDate),
                            fromDate = conversionDate(newItem.PriorNoticeForRenewalForIPSFrom);
                        if (fromDate <= chkDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.PriorNoticeForRenewalForIPSTo == 'undefined' || !newItem.PriorNoticeForRenewalForIPSTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.PriorNoticeForRenewalForIPS != null) {
                        var chkiDate = dateFormat(v.PriorNoticeForRenewalForIPS);
                        var chkDate = conversionDate(chkiDate),
                            toDate = conversionDate(newItem.PriorNoticeForRenewalForIPSTo);
                        if (chkDate <= toDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.RenewedEffectiveDateToFrom == 'undefined' || !newItem.RenewedEffectiveDateToFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.RenewedEffectiveDateTo != null) {
                        var chkiDate = dateFormat(v.RenewedEffectiveDateTo);
                        var chkDate = conversionDate(chkiDate),
                            fromDate = conversionDate(newItem.RenewedEffectiveDateToFrom);
                        if (fromDate <= chkDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.RenewedEffectiveDateToTo == 'undefined' || !newItem.RenewedEffectiveDateToTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.RenewedEffectiveDateTo != null) {
                        var chkiDate = dateFormat(v.RenewedEffectiveDateTo);
                        var chkDate = conversionDate(chkiDate),
                            toDate = conversionDate(newItem.RenewedEffectiveDateToTo);
                        if (chkDate <= toDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.SealedDateFrom == 'undefined' || !newItem.SealedDateFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.SealedDate != null) {
                        var chkiDate = dateFormat(v.SealedDate);
                        var chkDate = conversionDate(chkiDate),
                            fromDate = conversionDate(newItem.SealedDateFrom);
                        if (fromDate <= chkDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.SealedDateTo == 'undefined' || !newItem.SealedDateTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.SealedDate != null) {
                        var chkiDate = dateFormat(v.SealedDate);
                        var chkDate = conversionDate(chkiDate),
                            toDate = conversionDate(newItem.SealedDateTo);
                        if (chkDate <= toDate) {
                            return true;
                        }
                    }
                });
            }
            if (!(typeof newItem.Contractant == 'undefined' || !newItem.Contractant)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.Contractant != null) return angular.lowercase(v.Contractant).indexOf(angular.lowercase(newItem.Contractant)) !== -1;
                });
            }
            if (!(typeof newItem.EntityAtTimeOfContracted == 'undefined' || !newItem.EntityAtTimeOfContracted)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.EntityAtTimeOfContracted != null) return angular.lowercase(v.EntityAtTimeOfContracted).indexOf(angular.lowercase(newItem.EntityAtTimeOfContracted)) !== -1;
                });
            }
            if (!(typeof newItem.ContractType == 'undefined' || !newItem.ContractType)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractType != null) return angular.lowercase(v.ContractType).indexOf(angular.lowercase(newItem.ContractType)) !== -1;
                });
            }
            if (!(typeof newItem.ContractTypeOther == 'undefined' || !newItem.ContractTypeOther)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractTypeOther != null) return angular.lowercase(v.ContractTypeOther).indexOf(angular.lowercase(newItem.ContractTypeOther)) !== -1;
                });
            }
            if (!(typeof newItem.ContractHolderLEG == 'undefined' || !newItem.ContractHolderLEG)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractHolder_LEG != null) return angular.lowercase(v.ContractHolder_LEG).indexOf(angular.lowercase(newItem.ContractHolderLEG)) !== -1;
                });
            }
            if (!(typeof newItem.ContractHolder_Dept == 'undefined' || !newItem.ContractHolder_Dept)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractHolder_Dept != null) return angular.lowercase(v.ContractHolder_Dept).indexOf(angular.lowercase(newItem.ContractHolder_Dept)) !== -1;
                });
            }
            if (!(typeof newItem.EntryDepartment == 'undefined' || !newItem.EntryDepartment)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.EntryDepartment != null) return angular.lowercase(v.EntryDepartment).indexOf(angular.lowercase(newItem.EntryDepartment)) !== -1;
                });
            }
            if (!(typeof newItem.ContractHandedOverTo == 'undefined' || !newItem.ContractHandedOverTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractHandedOverTo != null) return angular.lowercase(v.ContractHandedOverTo).indexOf(angular.lowercase(newItem.ContractHandedOverTo)) !== -1;
                });
            }
            if (!(typeof newItem.CurrentResponsibleDepartment == 'undefined' || !newItem.CurrentResponsibleDepartment)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.CurrentResponsibleDepartment != null) return angular.lowercase(v.CurrentResponsibleDepartment).indexOf(angular.lowercase(newItem.CurrentResponsibleDepartment)) !== -1;
                });
            }
            if (!(typeof newItem.CurrentContactPerson == 'undefined' || !newItem.CurrentContactPerson)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.CurrentContactPerson != null) return angular.lowercase(v.CurrentContactPerson).indexOf(angular.lowercase(newItem.CurrentContactPerson)) !== -1;
                });
            }
            if (!(typeof newItem.ContractMemo == 'undefined' || !newItem.ContractMemo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.Memo != null) {
                        var tag = document.createElement('div');
                        tag.innerHTML = v.Memo;
                        tag.innerText = tag.innerText.replace(/\r?\n?/g, '');
                        return angular.lowercase(tag.innerText.trim()).indexOf(angular.lowercase(newItem.ContractMemo)) !== -1;
                    }
                });
            }
            if (!(typeof newItem.LinkToOtherContracts == 'undefined' || !newItem.LinkToOtherContracts)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.LinkToOtherContracts != null) return angular.lowercase(v.LinkToOtherContracts).indexOf(angular.lowercase(newItem.LinkToOtherContracts)) !== -1;
                });
            }
            if (!(typeof newItem.ContractPurpose == 'undefined' || !newItem.ContractPurpose.trim())) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractPurpose != null) return angular.lowercase(v.ContractPurpose).indexOf(angular.lowercase(newItem.ContractPurpose)) !== -1;
                });
            }
            if (!(typeof newItem.StampDuty == 'undefined' || !newItem.StampDuty)) {
                 $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.StampDuty != null) return angular.lowercase(v.StampDuty).indexOf(angular.lowercase(newItem.StampDuty)) !== -1;
                 });
            }
            if (!(typeof newItem.AntibriberyClause == 'undefined' || !newItem.AntibriberyClause)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.AntibriberyClause != null) return angular.lowercase(v.AntibriberyClause).indexOf(angular.lowercase(newItem.AntibriberyClause)) !== -1;
                });
            }
            if (!(typeof newItem.ContractHolderChoice == 'undefined' || !newItem.ContractHolderChoice)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractHolderChoice != null) return angular.lowercase(v.ContractHolderChoice).indexOf(angular.lowercase(newItem.ContractHolderChoice)) !== -1;
                });
            }
            if (!(typeof newItem.UnitPriceAgreed == 'undefined' || !newItem.UnitPriceAgreed)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.UnitPriceAgreed != null) return angular.lowercase(v.UnitPriceAgreed).indexOf(angular.lowercase(newItem.UnitPriceAgreed)) !== -1;
                });
            }
            if (!(typeof newItem.IPSrelated == 'undefined' || !newItem.IPSrelated)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.IPSrelated != null) return angular.lowercase(v.IPSrelated).indexOf(angular.lowercase(newItem.IPSrelated)) !== -1;
                });
            }
            if (!(typeof newItem.AutomaticRenewal == 'undefined' || !newItem.AutomaticRenewal)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.AutomaticRenewal != null) return angular.lowercase(v.AutomaticRenewal).indexOf(angular.lowercase(newItem.AutomaticRenewal)) !== -1;
                });
            }
            if (!(typeof newItem.ProcurementTerminationFlag == 'undefined' || !newItem.ProcurementTerminationFlag)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ProcurementTerminationFlag != null) return angular.lowercase(v.ProcurementTerminationFlag).indexOf(angular.lowercase(newItem.ProcurementTerminationFlag)) !== -1;
                });
            }
            if (!(typeof newItem.Currency == 'undefined' || !newItem.Currency)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.Currency != null) return angular.lowercase(v.Currency).indexOf(angular.lowercase(newItem.Currency)) !== -1;
                });
            }
            if (!(typeof newItem.ContractAmountFrom == 'undefined' || !newItem.ContractAmountFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractAmount != null) {
                        var ca = Number(v.ContractAmount);
                        if (Number(ca >= newItem.ContractAmountFrom)) return true;
                    }
                });
            }
            if (!(typeof newItem.ContractAmountTo == 'undefined' || !newItem.ContractAmountTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.ContractAmount != null) {
                        var ca = Number(v.ContractAmount);
                        if (ca <= Number(newItem.ContractAmountTo)) return true;
                    }
                });
            }
            if (!(typeof newItem.AmountofStampDuty1From == 'undefined' || !newItem.AmountofStampDuty1From)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.AmountofStampDuty1 != null) {
                        var ca = Number(v.AmountofStampDuty1);
                        if (Number(ca >= newItem.AmountofStampDuty1From)) return true;
                    }
                });
            }
            if (!(typeof newItem.AmountofStampDuty1To == 'undefined' || !newItem.AmountofStampDuty1To)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.AmountofStampDuty1 != null) {
                        var ca = Number(v.AmountofStampDuty1);
                        if (ca <= Number(newItem.AmountofStampDuty1To)) return true;
                    }
                });
            }
            if (!(typeof newItem.AmountofStampDuty2From == 'undefined' || !newItem.AmountofStampDuty2From)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.AmountofStampDuty2 != null) {
                        var ca = Number(v.AmountofStampDuty2);
                        if (Number(ca >= newItem.AmountofStampDuty2From)) return true;
                    }
                });
            }
            if (!(typeof newItem.AmountofStampDuty2To == 'undefined' || !newItem.AmountofStampDuty2To)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.AmountofStampDuty2 != null) {
                        var ca = Number(v.AmountofStampDuty2);
                        if (ca <= Number(newItem.AmountofStampDuty2To)) return true;
                    }
                });
            }
            if (!(typeof newItem.PriorNoticeForRenewalFrom == 'undefined' || !newItem.PriorNoticeForRenewalFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.PriorNoticeForRenewal != null) {
                        var ca = Number(v.PriorNoticeForRenewal);
                        if (Number(ca >= newItem.PriorNoticeForRenewalFrom)) return true;
                    }
                });
            }
            if (!(typeof newItem.PriorNoticeForRenewalTo == 'undefined' || !newItem.PriorNoticeForRenewalTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.PriorNoticeForRenewal != null) {
                        var ca = Number(v.PriorNoticeForRenewal);
                        if (ca <= Number(newItem.PriorNoticeForRenewalTo)) return true;
                    }
                });
            }
            if (!(typeof newItem.RenewalPeriodFrom == 'undefined' || !newItem.RenewalPeriodFrom)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.RenewalPeriod != null) {
                        var ca = Number(v.RenewalPeriod);
                        if (Number(ca >= newItem.RenewalPeriodFrom)) return true;
                    }
                });
            }
            if (!(typeof newItem.RenewalPeriodTo == 'undefined' || !newItem.RenewalPeriodTo)) {
                $scope.tempItems = $.grep($scope.tempItems, function (v) {
                    if (v.RenewalPeriod != null) {
                        var ca = Number(v.RenewalPeriod);
                        if (ca <= Number(newItem.RenewalPeriodTo)) return true;
                    }
                });
            }
            $scope.gridOptions.api.setRowData($scope.tempItems);

            $scope.ResultCount = $scope.tempItems.length;
            $scope.TrimCount = $scope.tempItems.length;
            if ($scope.TrimCount > 300) {
                $scope.TrimCount == 300;
            }
        }


        else {
            $scope.searchResults = false;
            $scope.isExportDisabled = true;
            $scope.displayMessage = true;
            $scope.errMessage = "Please enter any search parameter";
        }
    }
    function conversionDate(dateString) {
        var chkDateArray = dateString;
        chkDateArray = dateString.split('/');
        var myDate = new Date(chkDateArray[0], chkDateArray[1] - 1, chkDateArray[2]);
        return myDate;
    }
    $scope.status = {
        isFirstOpen: true
    };
    $scope.state = {
        open: true,
        isFirstOpen: true
    };
    $scope.btnClear = function () {
        //$scope.newItem = '';
        $scope.errMessage = '';
        $scope.searchResults = false;
        $scope.displayMessage = false;
        $scope.isExportDisabled = true;
        $scope.newItem = {

            SimpleFromdate: [],
            SimpleTodate: [],
            cbs: []

        };
    }

    $scope.changedListViewValue = function (item) {
        if (item.name == "(For MBJ) All Items") {
            angular.forEach(columnDefs, function (col) {
                $scope.gridOptions.columnApi.setColumnVisible(col.field, true);
            });
           // $scope.gridOptions.columnApi.setColumnVisible('Title', false);
            $scope.gridOptions.columnApi.setColumnVisible('ListName&ID&Title', true);
            $scope.gridOptions.columnApi.setColumnVisible('Sealed Date', false);
             $scope.gridOptions.columnApi.setColumnVisible('StampDuty', false);
        }
        else {
            angular.forEach(columnDefs, function (col) {
                $scope.gridOptions.columnApi.setColumnVisible(col.field, false);
            });
            if (item.name == "(For MBJ) MBJ Summary") {
                $scope.gridOptions.columnApi.setColumnVisible('ContractStatus', true);
                $scope.gridOptions.columnApi.setColumnVisible('ListName&ID&Title', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor1_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractName', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractDate', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContactPerson', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractDept', true);
            }
            if (item.name == "(For MBJ) IPS View") {
                $scope.gridOptions.columnApi.setColumnVisible('ListName&ID&Title', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractStatus', true);
              //  $scope.gridOptions.columnApi.setColumnVisible('Title', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor1_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor2_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor1_EN', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor2_EN', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractHolderChoice', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractHolder_LEG', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractHolder_Dept', true);
                $scope.gridOptions.columnApi.setColumnVisible('LocationNumber', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractName', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractType', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractTypeOther', true);
                $scope.gridOptions.columnApi.setColumnVisible('IPSrelated', true);
                $scope.gridOptions.columnApi.setColumnVisible('EntryDepartment', true);
                $scope.gridOptions.columnApi.setColumnVisible('EffectiveDateFrom', true);
                $scope.gridOptions.columnApi.setColumnVisible('EffectiveDateTo', true);
                $scope.gridOptions.columnApi.setColumnVisible('LegalTerminatedDateActual', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractDept', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContactPerson', true);
                $scope.gridOptions.columnApi.setColumnVisible('AutomaticRenewal', true);
                $scope.gridOptions.columnApi.setColumnVisible('RenewalPeriod', true);
                $scope.gridOptions.columnApi.setColumnVisible('RenewedEffectiveDateTo', true);
                $scope.gridOptions.columnApi.setColumnVisible('PriorNoticeForRenewal', true);
                $scope.gridOptions.columnApi.setColumnVisible('PriorNoticeForRenewalForIPS', true);
                $scope.gridOptions.columnApi.setColumnVisible('ProcurementTerminationFlag', true);
                $scope.gridOptions.columnApi.setColumnVisible('CurrentResponsibleDepartment', true);
                $scope.gridOptions.columnApi.setColumnVisible('CurrentContactPerson', true);
                $scope.gridOptions.columnApi.setColumnVisible('Memo', true);
            }
            if (item.name == "(For MBJ) LEG Summary") {
                
                $scope.gridOptions.columnApi.setColumnVisible('ListName&ID&Title', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractStatus', true);
               // $scope.gridOptions.columnApi.setColumnVisible('Title', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor1_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractName', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractDate', true);
                $scope.gridOptions.columnApi.setColumnVisible('LocationNumber', true);
                $scope.gridOptions.columnApi.moveColumn('ContractStatus',0);
            }
            if (item.name == "(For MBJ) Dept Managed") {
                $scope.gridOptions.columnApi.setColumnVisible('ListName&ID&Title', true);
               // $scope.gridOptions.columnApi.setColumnVisible('Title', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor1_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor1_EN', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor2_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor2_EN', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractDate', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractName', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractType', true);
                $scope.gridOptions.columnApi.setColumnVisible('LocationNumber', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractantCode', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractDept', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContactPerson', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractHolderChoice', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractHolder_LEG', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractHolder_Dept', true);
                $scope.gridOptions.columnApi.setColumnVisible('LegalTerminatedDateActual', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor3_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor3_EN', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor4_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor4_EN', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor5_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor5_EN', true);
               // $scope.gridOptions.columnApi.setColumnVisible('Remarks', true);
               // $scope.gridOptions.columnApi.setColumnVisible('Remarks_LEGIPS', true);
                // $scope.gridOptions.columnApi.setColumnVisible('Attachment', true);
            }
            if (item.name == "(For FS) All Items") {
                $scope.gridOptions.columnApi.setColumnVisible('ListName&ID&Title', true);

                $scope.gridOptions.columnApi.setColumnVisible('ContractName', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractant', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractDept', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContactPerson', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor1_JP', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor1_EN', true);
                $scope.gridOptions.columnApi.setColumnVisible('Contractor2_EN', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractType', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractTypeOther', true);
                // $scope.gridOptions.columnApi.setColumnVisible('Attachment', true);
                $scope.gridOptions.columnApi.setColumnVisible('LinkToOtherContracts', true);
                //$scope.gridOptions.columnApi.setColumnVisible('Remarks', true);
                $scope.gridOptions.columnApi.setColumnVisible('LocationNumber', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractantCode', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractDate', true);
                $scope.gridOptions.columnApi.setColumnVisible('EffectiveDateFrom', true);
                $scope.gridOptions.columnApi.setColumnVisible('EffectiveDateTo', true);
                $scope.gridOptions.columnApi.setColumnVisible('AutomaticRenewal', true);
                $scope.gridOptions.columnApi.setColumnVisible('LegalTerminatedDateActual', true);
                $scope.gridOptions.columnApi.setColumnVisible('AntibriberyClause', true);
                //$scope.gridOptions.columnApi.setColumnVisible('EliminatingAntiSocialForces', true);
                //$scope.gridOptions.columnApi.setColumnVisible('DataProtectionClause', true);
                // $scope.gridOptions.columnApi.setColumnVisible('Outsourcing', true);
                // $scope.gridOptions.columnApi.setColumnVisible('Supplier', true);
                // $scope.gridOptions.columnApi.setColumnVisible('SalesBusinessPartner', true);
                $scope.gridOptions.columnApi.setColumnVisible('EntryDate', true);
                $scope.gridOptions.columnApi.setColumnVisible('EntryDepartment', true);
                $scope.gridOptions.columnApi.setColumnVisible('ContractHolderChoice', true);

            }
        }
    }


    $scope.btnExport = function () {
        var params = {
            // skipHeader: getBooleanValue('#skipHeader'),
            // columnGroups: getBooleanValue('#columnGroups'),
            // skipFooters: getBooleanValue('#skipFooters'),
            // skipGroups: getBooleanValue('#skipGroups'),
            // skipPinnedTop: getBooleanValue('#skipPinnedTop'),
            // skipPinnedBottom: getBooleanValue('#skipPinnedBottom'),
            // allColumns: getBooleanValue('#allColumns'),
            // onlySelected: getBooleanValue('#onlySelected'),
            fileName: "ContractDB",
            sheetName: "contract"
        };


        $scope.gridOptions.api.exportDataAsExcel(params);
    }

    $scope.gridOptions = {
        columnDefs: columnDefs,
        enableSorting: true,
        ExcelStyles: [],
        rowData: $scope.rowData,
        rowSelection: 'single',
        enableColResize: true,
        angularCompileRows: false,
        toolPanelSuppressSideButtons: true,
        domLayout: 'autoHeight',

    };


});
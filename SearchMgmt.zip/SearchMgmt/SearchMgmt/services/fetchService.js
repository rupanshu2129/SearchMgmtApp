searchApp.service('fetchService', ['$http', '$q', function ($http, $q) {
    //Define the headers
    $http.defaults.headers.common.Accept = "application/json;odata=verbose";
    $http.defaults.headers.post['Content-Type'] = 'application/json;odata=verbose';
    $http.defaults.headers.post['X-Requested-With'] = 'XMLHttpRequest';
    $http.defaults.headers.post['If-Match'] = "*";
    this.getItems = function (listTitle) {
        var dfd = $q.defer();
        $http.defaults.headers.post['X-HTTP-Method'] = ""
        var restUrl = "https://team.uat.sp.wp.corpintra.net/sites/05420/MBJContractDB/_api/web/lists/getbytitle('" + listTitle + "')/items?$top=5000";
        $http.get(restUrl).success(function (data) {
            dfd.resolve(data.d.results);
        }).error(function (data) {
            dfd.reject("error getting items");
        });
        return dfd.promise;
    }

}]);